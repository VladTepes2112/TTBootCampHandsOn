package com.victor.hands_on_6;

import org.springframework.data.repository.CrudRepository;

public interface ProductsREPO extends CrudRepository <Product, Integer> {

}
