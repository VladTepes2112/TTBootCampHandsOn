package com.victor.hands_on_6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HandsOn5Application {

    public static void main(String[] args) {
        SpringApplication.run(HandsOn5Application.class, args);
    }
}
