package com.victor.hands_on_6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HandsOn5ApplicationTests {

    @Test
    void contextLoads() {
    }

}
